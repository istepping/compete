# kaggle_kidney
HuBMAP: Hacking the Kidney Kaggle competition
